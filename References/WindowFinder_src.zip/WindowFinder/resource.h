//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_CURSOR_SEARCH_WINDOW        101
#define IDR_MENU_MAIN                   102
#define IDD_DIALOG_SEARCH_WINDOW        103
#define IDB_BITMAP_FINDER_EMPTY         106
#define IDB_BITMAP_FINDER_FILLED        107
#define IDC_STATIC_X_POS                1000
#define IDC_STATIC_Y_POS                1001
#define IDC_EDIT_STATUS                 1002
#define IDC_STATIC_ICON_FINDER_TOOL     1003
#define IDM_FIND_WINDOW                 40001
#define IDM_ABOUT                       40002
#define IDM_EXIT                        40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
